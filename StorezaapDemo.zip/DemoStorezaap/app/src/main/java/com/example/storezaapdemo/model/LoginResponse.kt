package com.example.storezaapdemo.model

class LoginResponse(var user: User?, var error: String?, var message: String?)