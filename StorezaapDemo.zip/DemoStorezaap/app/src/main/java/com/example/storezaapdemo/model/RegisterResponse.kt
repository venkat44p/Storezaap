package com.example.storezaapdemo.model

class RegisterResponse(var error: String?, var message: String?) {
}