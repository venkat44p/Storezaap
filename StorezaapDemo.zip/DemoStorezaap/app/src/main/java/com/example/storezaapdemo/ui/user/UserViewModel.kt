package com.example.storezaapdemo.ui.user

import androidx.lifecycle.ViewModel

class UserViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}