package com.example.storezaapdemo.model

class User(var id: String?, var username: String?, var email: String?)