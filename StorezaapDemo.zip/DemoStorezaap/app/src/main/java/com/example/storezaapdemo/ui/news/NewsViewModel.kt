package com.example.storezaapdemo.ui.news

import androidx.lifecycle.ViewModel

class NewsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}