package com.example.storezaapdemo.ui.store

import androidx.lifecycle.ViewModel

class StoreViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}